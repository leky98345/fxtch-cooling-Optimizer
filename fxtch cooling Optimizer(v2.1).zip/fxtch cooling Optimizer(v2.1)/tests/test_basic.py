def test_true():
    assert True
