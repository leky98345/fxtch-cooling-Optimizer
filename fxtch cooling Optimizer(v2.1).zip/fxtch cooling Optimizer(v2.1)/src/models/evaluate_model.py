from sklearn.metrics import mean_squared_error
from src.models.train_model import train
from src.data.load_data import load_processed

def evaluate():
    model = train()
    df = load_processed()
    X = df[["temp_norm", "humidity"]]
    y = df["power_usage"]

    preds = model.predict(X)
    return mean_squared_error(y, preds)
