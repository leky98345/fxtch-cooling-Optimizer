import random

def random_optimization():
    best = None
    for i in range(10):
        config = {
            "fan_speed": random.randint(1, 5),
            "cooling_level": random.randint(1, 10),
            "power_limit": random.randint(200, 600)
        }
        score = random.random()
        if best is None or score < best["score"]:
            best = {"config": config, "score": score}
    return best
