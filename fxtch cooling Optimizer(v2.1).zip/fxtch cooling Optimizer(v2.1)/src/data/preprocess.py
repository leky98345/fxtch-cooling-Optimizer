def normalize_temp(df):
    df["temp_norm"] = (df["temp"] - df["temp"].min()) / (df["temp"].max() - df["temp"].min())
    return df

def preprocess_raw(df):
    df = df.dropna()
    return normalize_temp(df)
