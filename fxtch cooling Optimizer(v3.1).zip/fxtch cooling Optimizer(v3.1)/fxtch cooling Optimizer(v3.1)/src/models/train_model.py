from sklearn.linear_model import LinearRegression
from src.data.load_data import load_processed

def train():
    df = load_processed()
    X = df[["temp_norm", "humidity"]]
    y = df["power_usage"]

    model = LinearRegression()
    model.fit(X, y)
    return model
