# -- fxtch cooling tweaks(v3.1)

This is a project for cooling optimization.

It contains:
- cooling optimization
- ram tweaker
- fan speed optimization
- basic optimization


