import pandas as pd

def load_raw(path="data/raw/raw_data.csv"):
    return pd.read_csv(path)

def load_processed(path="data/processed/processed_data.csv"):
    return pd.read_csv(path)
