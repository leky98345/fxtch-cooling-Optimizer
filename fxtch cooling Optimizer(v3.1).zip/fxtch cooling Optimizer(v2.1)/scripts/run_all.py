from src.models.evaluate_model import evaluate
from src.optimization.optimize_cooling import random_optimization

if __name__ == "__main__":
    print("MSE:", evaluate())
    print("Best config:", random_optimization())
